
import React from "react";


function  Intro_proceso(){
    return(
<div>
    <div id="introduccion" className="container-fluid fondo">
                <div className="container">
                    <div className="row p-5">
                        <div className="col-12 col-lg-9 p-5">
                            <div className="introduccion ">
                                <h1 className="Titulo d-flex justify-content-center text-center ">INTRODUCCION</h1>
                                <p className="Texto">Enla actulidad se a evidenciado una falencia,Con respecto al codigo de de
                                    policia,
                                    especialmente enfocado en el maltrato animal ,esta problematica ha surgido ya que todos
                                    no tienen un conocimiento
                                    del codigo de policia y notiene presentes las concecuencias que esto puede conllevar
                                    faltas graves.
                                </p>
                            </div>
                        </div>
                        <div className="col-12 col-lg-3 d-flex justify-content-center">
                            <div>
                                <img src="../public/img/pngwing.com (4).png" className="img-fluid " alt=""/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div id="proceso" className="container-fluid ">
                 <div className="row p-5">
                        <div className="col-12 col-lg-3 d-flex justify-content-center ">
                            <div>
                                <img src="../public/img/pngwing.com (5).png" className="img-fluid" alt=""/>
                            </div>
                        </div>
                        <div className="col-12 col-lg-9">
                            <div className="ELABORACION">
                                <h1 className="Titulo d-flex justify-content-center text-center">PROCESO DE ELABORACION</h1>
                                <p className="Texto">
                                    Principalmente empezamos con el pitchbook, el cual es, un documento de investigación
                                    que consta de varias fases (objetivos, misión, visión ETC). Este proceso es muy importante
                                    para la elaboración del Manual Corporativo que de manera resumida es una metodología
                                    de investigación donde se lleva a cabo un proceso de bocetaje para escoger el diseño de un
                                    logo final, que representará la marca
                                </p>
                            </div>
                        </div>
                  </div>
               </div> 
               <hr />
</div>

    )

}
export default Intro_proceso