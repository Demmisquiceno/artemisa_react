import React from 'react'
import './App.css'
import Contenido from './Contenido'
import Intro_proceso from './Intro_proceso'
import Artemsia from './Artemisa'
import Creadores from './creadores'
import Personajes from './Personajes'
import Diviertete from './Diviertete'
import Final from './Final'
import Parte_2 from './parte_2'



function App() {


  return (
    <div>
      <Artemsia/>
      <Contenido/>
      <Intro_proceso/>
      <Creadores/>
      <Personajes/>
      <Parte_2/>
      <Diviertete/>
      <Final/>
    </div>
  )
}
export default App
