
import React from "react";


function Contenido(){

    return(
        <div>
            <div id="despripcion"  className="container-fluid fondo">
            <div className="container">
            <div className="row p-5">
                <div className="col-12 col-lg-9 p-5 ">
                    <div className="descripcion-proyecto ">
                        <h1 className="Titulo d-flex justify-content-center text-center ">Descripcion del Proyecto</h1>
                        <p className="Texto">Consiste en un juego web llamado ARTEMISA sobre el codigo
                            de policia, enfocandose en el maltrato animal, este juego niveles y
                            cada nivel tendra un enfoque de aprendizaje diferente.
                            Tendremos un sitio web para dar un acompañamiento exclusivo a los jugadores
                            que lo necesiten. 
                        </p>
                    </div>
                </div>

                <div className="col-12 col-lg-3 d-flex justify-content-center">
                    <div>
                        <img src="../public/img/pngwing.com.png" className="img-fluid " alt=""/>
                    </div>
                </div>
            </div>
            </div>
        </div>
        
        <div className="container">
            <div className="row p-5">
                <div className="col-12 col-lg-3 d-flex justify-content-center">
                <div>
                 <img src="../public/img/pngwing.com (3).png" className="img-fluid" alt=""/>
                        </div>
                </div>
                <div className="col-12 col-lg-9 p-5">
                <div className="objetivo-proyecto  ">
                            <h1 className="Titulo d-flex justify-content-center text-center">OBJETIVO DEL PROYECTO</h1>
                            <p className="Texto">Enseñar a las personas entre los (17 y 19 años) la importancia
                                de tener conocimiento del codigo de policia, enfocandonos en el maltrato animal,
                                dejando en claro sus consecuencias y lo importante que es esta ley.
                            </p>
                        </div>
                </div>
            </div>
        </div>
     <hr />
        </div>
        
    
    
        )
    
}
export default  Contenido