import React from "react";

function Personajes(props) {
  return (
    <div>
      <div className="row p-4">
        <div className="col-12 col-lg-10  ">
          <p className="fs1 d-flex justify-content-start text-center Titulo Titulo1">
            {props.Titulo1}
          </p>
        </div>

        <div className="col-12 col-lg-9 ">
          <p className="fs1 d-flex justify-content-start text-center Texto Texto1">
            {props.Texto1}
          </p>
        </div>
      </div>

      <div className="row p-4">
        <div className="col-12 col-lg-9 ">
          <p className="fs1 d-flex justify-content-start text-center Titulo Titulo2">
            {props.Titulo2}
          </p>
        </div>

        <div className="col-12 col-lg-9 ">
          <p className="fs1 d-flex justify-content-start text-center Texto Texto2">
            {props.Texto2}
          </p>
        </div>
      </div>
    </div>
  );
}

export default Personajes;