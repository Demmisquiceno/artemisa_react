import React from "react";

function Diviertete(){

    return(
        <div>
            <hr />
                <div  id="btn"  className="Titulo text-center">DIVIERTETE-Boton del juego</div>
            <div className="container-fluid">
                <div className="row">
                    <div className="d-grid gap-2 col-6 mx-auto">
                        <div className="d-flex justify-content-center">

                        <button   className=" Diviertete Titulo  " type="button">DIVIERTETE</button>
                        
                        </div>
                        <h1 className="Texto text-center">Que esperas para comenzar a jugar</h1>

                    </div>
                </div>
            </div>
            <hr />
        </div>
       
    )
}
export default Diviertete