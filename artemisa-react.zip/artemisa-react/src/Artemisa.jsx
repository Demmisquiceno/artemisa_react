
import React from "react";


function Artemisa(){

    return(
        <div className="container-fluid">
 {/*        <!-- LOGO Y MENU --> */}
        <div className="row">
            <div className="col-12 col-lg-4 p-4 d-flex justify-content-center align-items-center">
            <img src="../public/img/ARTEMISA-VECTORISADO-.png" className="logo" alt=""/>
            </div>
            <div className="col-12 col-lg-7 d-flex justify-content-end align-items-center ">


              <ul className="navbar navbar-expand-lg">
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                  </button>
                   <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                  <div className="navbar-nav">
                       
              <li className="nav-item dropdown  text-CAESAR barra-menu">
                <a className="nav-link dropdown-toggle Titulo " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> 
                 ARTEMISA </a>
                <ul className="dropdown-menu">
                    <li><a className="dropdown-item" href="#despripcion">DESCRIPCION DEL PROYECTO</a></li>
                    <li className="dropdown-divider"></li>
                    <li><a className="dropdown-item" href="#introduccion">INTRODUCCION</a></li>
                  
                </ul>
              </li>

              <li className="nav-item dropdown  text-CAESAR barra-menu  ">
                <a className="nav-link dropdown-toggle Titulo " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" > 
                     MEMORIAS </a>
                <ul className="dropdown-menu ">
                    <li><a className="dropdown-item" href="#creadores">CREADORES</a></li>
                    <li><a className="dropdown-item" href="#personajes">PERSONAJES PRINCIPALES</a></li>
                </ul>
              </li>
                <ul className="nav nav-pills text-CAESAR barra-menu">
                    <li className="nav-item Titulo">
                        <a className="nav-link gh" href="#btn">DIVIERTETE</a>
                    </li>
                </ul>
                </div>
              </div>
            </ul>
            </div>
        </div>
    </div>
    )

}
export default Artemisa