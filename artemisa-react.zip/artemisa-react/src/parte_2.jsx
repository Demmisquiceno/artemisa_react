import React from "react";
import Personajes from './Personajes';

function Parte_2(props){
    return(
        <div className="caja">
           <Personajes
        Titulo1="APOLO"
        Texto1="Es un perro fantasma , el cual sufrio de maltrato animal por su antiguo por su dueño quien termino por 
        causarle la muerte, pero este queda en el plano terrenal ya que tiene una mision que cumplir, antes de poder 
        descansar en paz."
        />

      <Personajes
        Titulo2="GASPAR"
        Texto2="Es un perro amigo de apolo, es un perro que ha sufrido mucho maltrato animal y al ver sus amigos apolo 
        muerto le causa un sentimiento de tristeza y lo largo de la historia Gaspar sufre de muchas cosas,
        no es un perro grosero ni agesivo."
        />
         
        </div>
     

    
    )
}
export default Parte_2