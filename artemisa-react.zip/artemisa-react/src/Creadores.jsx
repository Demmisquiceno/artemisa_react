import React from "react";

function Creadores (){
    return(
      <div>
         <div id="creadores" className="container">
             <div className="row">
                 <div className="col-12 col-lg-6 d-flex justify-content-center p-4">
                    <div className="card">
                        <img src="../public/img/Demmis-.jpg" className="card-img-top" alt="..."/>
                        <div className="card-body">
                            <h1 className="Titulo">Demmis Quiceno</h1>
                            <p className="card-text">
                            soy una persona muy alegre, me gusta ayudar en todo, mis grandes sueños
                            serian ser una gran fotografa y una profesional en diseño grafico.
                            </p>
                        </div>
                    </div>
                </div>

                    <div className="col-12 col-lg-6 d-flex justify-content-center p-4">
                        <div className="card">
                            <img src="../public/img/Esneider-.jpg" className="card-img-top" alt="..."/>
                            <div className="card-body">
                                <h1 className="Titulo">Esneider Vasquez</h1>
                               <p className="card-text">
                                soy una gran persona me gusta ayudar a los demas, me gusta mucho la programacion,
                                me gusta aprender cosas nueva para auto superarme cada dia.
                                </p>
                            </div>
            
                        </div>
                    </div>
             </div>
        </div>
        <hr />
      </div>
       
    )
}
export default Creadores