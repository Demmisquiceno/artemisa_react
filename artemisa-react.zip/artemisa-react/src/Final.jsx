import React from "react";

function Final(){

    return(
        <div>
            <div className="container-fluid fondo">
            <div className="container">
                <div className="row ">
                    <div className="logo-pie-pagina d-flex justify-content-center p-4">
                        <img src="../public/img/ARTEMISA-VECTORISADO-.png" className="logo" alt=""/>
                    </div>
                </div>
            </div>
            <div className="container">
                <div className="row">
                    <div className="col-12 col-lg-12  d-flex justify-content-center">
                        
                        <img src="../public/img/redes-sociales.png" className="redes " alt=""/>
                
                    </div>
                </div>
            </div>
            <div className="col-12 col-lg-12 ">
                <div className="text-center">
                    <small className="text-textos">&copy;ARTEMISA.
                        Todos los derechos reservados
                    </small>
                </div>
            </div>
        </div>
          
        </div>
       
    )
}
export default Final